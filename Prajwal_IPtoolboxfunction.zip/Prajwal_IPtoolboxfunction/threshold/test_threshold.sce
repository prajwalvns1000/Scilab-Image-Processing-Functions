exec('C:/Users/LENOVO/Downloads/threshold.sci');

// Sample grayscale image
img = [50 130 200; 10 180 90];

result = threshold(img);

disp(result);
