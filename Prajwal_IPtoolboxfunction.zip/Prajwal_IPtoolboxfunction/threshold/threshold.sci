function output = threshold(img)
    [rows, cols] = size(img);
    output = zeros(rows, cols);

    for i = 1:rows
        for j = 1:cols
            if img(i,j) > 128 then
                output(i,j) = 255;
            else
                output(i,j) = 0;
            end
        end
    end
endfunction
