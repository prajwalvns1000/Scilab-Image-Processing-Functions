Function Name: threshold

Description:
This function converts a grayscale image into binary using threshold 128.

Syntax:
output = threshold(img)

Parameters:
img - grayscale image

Test Cases:
1. 50 → 0
2. 130 → 255
3. 200 → 255
4. 10 → 0