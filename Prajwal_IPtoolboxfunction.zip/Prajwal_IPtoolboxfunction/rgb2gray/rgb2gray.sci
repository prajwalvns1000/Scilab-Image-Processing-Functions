function gray = rgb2gray(img)
    [rows, cols, channels] = size(img);
    gray = zeros(rows, cols);

    for i = 1:rows
        for j = 1:cols
            R = img(i,j,1);
            G = img(i,j,2);
            B = img(i,j,3);

            gray(i,j) = 0.299*R + 0.587*G + 0.114*B;
        end
    end
endfunction
