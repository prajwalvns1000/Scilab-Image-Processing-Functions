Function Name: rgb2gray

Description:
This function converts an RGB image into grayscale.

Syntax:
gray = rgb2gray(img)

Parameters:
img - RGB image (3D matrix)

Test Cases:
1. Red pixel → grayscale value
2. Green pixel → grayscale value
3. Blue pixel → grayscale value
4. Mixed RGB → correct grayscale