exec('C:/Users/LENOVO/Downloads/rgb2gray.sci');

// Sample RGB image (3D matrix)
img = zeros(2,2,3);

img(:,:,1) = [255 0; 0 255];   // Red
img(:,:,2) = [0 255; 0 255];   // Green
img(:,:,3) = [0 0; 255 255];   // Blue

result = rgb2gray(img);

disp(result);
