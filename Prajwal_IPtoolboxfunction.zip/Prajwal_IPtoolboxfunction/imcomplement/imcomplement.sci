function output = imcomplement(inputImg)
    [rows, cols] = size(inputImg);
    output = zeros(rows, cols);

    for i = 1:rows
        for j = 1:cols
            output(i,j) = 255 - inputImg(i,j);
        end
    end
endfunction
