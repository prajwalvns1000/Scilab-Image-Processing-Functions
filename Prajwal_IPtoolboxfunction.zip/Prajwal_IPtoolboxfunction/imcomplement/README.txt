Function Name: imcomplement

Description:
This function converts a grayscale image into its negative.

Syntax:
output = imcomplement(inputImg)

Parameters:
inputImg - input image matrix

Test Cases:
1. 0 → 255
2. 255 → 0
3. 100 → 155
4. 50 → 205