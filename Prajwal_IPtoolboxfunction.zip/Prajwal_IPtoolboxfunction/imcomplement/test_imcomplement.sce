// Load function
exec('C:/Users/LENOVO/Downloads/imcomplement.sci');

// Sample image (matrix)
img = [0 50 100; 150 200 255];

// Apply function
result = imcomplement(img);
disp(result);
//disp(result);
